/*
Antonio Josivaldo Dantas Filho
Sistemas de Informa��o - G7 - 580961
POO I - AA4.2 � Constru��o de uma classe em C++
*/

#include <cstdlib>
#include <time.h>
#include <iostream>

#define QUANTIDADE 64

using namespace std;

class televisao
{
private:
	bool ligada;
	bool canais[QUANTIDADE];
	int canal;
public:
    televisao();
    void ligar();
    void ligar(int);
    void procurarCanais();
    void mudarCanal(int);
    void desligar();
};

televisao::televisao()
{
	int i;
	for(i=0;i<QUANTIDADE;i++)
		canais[i]=false;
    ligada = false;
    canal = 0;    
}

void televisao::ligar()
{
    if(ligada){
   		cout << "\nA televisao esta ligada";
	}else
        cout << "\nA televisao ligou mude o canal";
    
    ligada = true;
}

void televisao::ligar(int c)
{
    if(ligada)
   		cout << "\nA televisao esta ligada";
	else
        cout << "\nA televisao ligou";
 
 	ligada = true;
    canal = c;
    
    if(canais[c-1])
		cout << " mudando canal para " << c;
	else
		cout << " canal nao disponivel";
}

void televisao::procurarCanais()
{
    int f, i;
    
    if (ligada)
    {
    	for(i=0;i<QUANTIDADE;i++){
    		f = rand()%100;
    		if (f > 80){
          		canais[i] = true;
          		cout << "\nO canal " << i+1 << " foi encontrado.";
          	}else
          		canais[i] = false;
		}
    }else
    	cout << "\nA televisao nao esta ligada";
}

void televisao::desligar()
{
    ligada = false;
}

void televisao::mudarCanal(int c)
{
	if(ligada){
	    if(canais[c-1])
			cout << "Mudando canal para " << c;
		else
			cout << "Canal nao disponivel";
		canal = c;
	}else
		cout << "A televisao esta desligada";
}

int opcoes()
{
    int op = 0;
    
    while (op < 1 || op > 5)
    {
          cout << "\n\n1. Ligar a televisao " << endl;
          cout << "2. Procurar Canais " << endl;
          cout << "3. Mudar de Canal " << endl;
          cout << "4. Desligar " << endl;
          cout << "5. Sair" << endl;
          cout << "Digite uma opcao: \n" << endl;
          cin >> op;
    }
    return op;
}

int main(int argc, char *argv[])
{
    int opcao, c;
    televisao t;
    
    srand(time(NULL));
    
    opcao = opcoes();
    
    while (opcao != 5)
    {
      switch(opcao){
    	case 1:
    		cout << "\nDigite o canal ou 0 para somente ligar:\n";
    		cin >> c;
    		if(c == 0)
    			t.ligar();
    		else
    			t.ligar(c);
    		break;
    	case 2:
    		t.procurarCanais();
    		break;
    	case 3:
    		cout << "\nDigite o canal:\n";
    		cin >> c;
    		t.mudarCanal(c);
    		break;
    	case 4:
    		t.desligar();
    		break;
    	default:
    		break;
	  }
      opcao = opcoes();        
    }
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
