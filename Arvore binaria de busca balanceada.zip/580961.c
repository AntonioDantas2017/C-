#include <stdio.h>

int mdc(int m, int n){
	if(n==0)
		return m;
	return mdc(n, m%n);
}

int mdc2(int m, int n){
	int a;
	
	if(n == 0) return m;
	if(m == 0) return m;	
	
	while(a != 0){
		a = n % m;
		n = m;
		m = a;	
	}
	
	return n;
}

int main(int argc, char *argv[])
{
	printf("\n%d %d",mdc(9,0),mdc2(9,0));
}
